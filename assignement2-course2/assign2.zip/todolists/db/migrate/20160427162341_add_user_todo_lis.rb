class AddUserTodoLis < ActiveRecord::Migration
  def change
  	 
  end
end
