class Addmanyreftotodolist < ActiveRecord::Migration
  
end
